package model;

public class GestionDatos {

	public GestionDatos() {

	}

	//TODO: Implementa una funci�n para abrir ficheros
	
	//TODO: Implementa una funci�n para cerrar ficheros
	
	public boolean compararContenido (String fichero1, String fichero2){
		//TODO: Implementa la funci�n
		return true;
	}
	
	public int buscarPalabra (String fichero1, String palabra, boolean primera_aparicion){
		//TODO: Implementa la funci�n
		return 1;
	}	

}
