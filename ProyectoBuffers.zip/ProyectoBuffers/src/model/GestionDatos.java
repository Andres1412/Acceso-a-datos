package model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class GestionDatos {

	public GestionDatos() {

	}
	//creamos el m�todo para comparar el contenido de los dos ficheros
	public static boolean compararContenido (String Fichero1, String Fichero2) throws IOException{//gestionamos la excepci�n
		
		BufferedReader[] buffer = new BufferedReader[2];//creamos un bufferedreader con array
		
		buffer[0] = abrirFicheros(Fichero1);//y definimos cada fichero a una posicion del array
		buffer[1] = abrirFicheros(Fichero2);// " "
		
		String txt = buffer[0].readLine();//creamos para que se pueda leer los archivos
		String txt2 = buffer[1].readLine();
		
			while(txt != null && txt2 != null) {//condicion mientras que no sean nulos o vacios que se ejecute...
				
				if(!txt.equals(txt2)) {//se ejecutan los if para si no son iguales que retorne false
					
					return false;
				
				} else {//en caso de que si que asigne los ficheros a los buffers
					
					txt = buffer[0].readLine();
					txt2 = buffer[1].readLine();
			
				}
			}
			
			cerrarFicheros(buffer[0]);
			cerrarFicheros(buffer[1]);
			
		return true;
	}
	
	public int buscarPalabra (String fichero1, String palabra, boolean primera_aparicion){
		//TODO: Implementa la funci�n
		return 1;
	}	
	
public  static  BufferedReader  abrirFicheros ( String  Fichero1 ) throws FileNotFoundException{
		
		FileReader read =  new  FileReader (Fichero1);
		BufferedReader buffer =  new  BufferedReader (read);
		
		return buffer;
	}
	
	public static void cerrarFicheros (BufferedReader buffered) throws IOException{
		
		buffered.close();
	}

}
