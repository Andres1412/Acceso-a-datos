package gestionficherosapp;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import gestionficheros.FormatoVistas;
import gestionficheros.GestionFicheros;
import gestionficheros.GestionFicherosException;
import gestionficheros.TipoOrden;

public class GestionFicherosImpl implements GestionFicheros {

	//creamos las variables
	private File carpetaDeTrabajo = null;
	private Object [][] contenido;
	private int filas = 0;
	private int columnas = 3;
	private FormatoVistas formatoVistas = FormatoVistas.NOMBRES;
	private TipoOrden ordenado = TipoOrden.DESORDENADO;

	public GestionFicherosImpl() {					

		carpetaDeTrabajo = File.listRoots()[0];
		actualiza();

	}

	private void actualiza() {//creamos el metodo el cual nos actualiza la base de datos
		// TODO Auto-generated method stub
		String[] ficheros = carpetaDeTrabajo.list(); // obtener los nombres
		// calcular el n�mero de filas necesario
		filas = ficheros.length / columnas;
		if (filas * columnas < ficheros.length) {
			filas++; // si hay resto necesitamos una fila m�s
		}

		// dimensionar la matriz contenido seg�n los resultados

		contenido = new String[filas][columnas];
		// Rellenar contenido con los nombres obtenidos
		for (int i = 0; i < columnas; i++) {
			for (int j = 0; j < filas; j++) {
				int ind = j * columnas + i;
				if (ind < ficheros.length) {
					contenido[j][i] = ficheros[ind];
				} else {
					contenido[j][i] = "";
				}
			}
		}
	}

	@Override
	public void arriba() {
		// TODO Auto-generated method stub
		if(carpetaDeTrabajo.getParentFile()!=null){
			
			carpetaDeTrabajo = carpetaDeTrabajo.getParentFile();
			actualiza();
			
		}
	}

	@Override
	public void creaCarpeta(String arg0) throws GestionFicherosException {//metodo para crear una carpeta nueva
		// TODO Auto-generated method stub
		
		File cTrabajo = new File (carpetaDeTrabajo, arg0);//se crea la variable de clase file
		
		if(!carpetaDeTrabajo.canWrite()) {//en el caso de que no se pueda escribir nos saldra un error
			
			throw new GestionFicherosException("La acci�n no se ha completado, no tienes permisos");//el error
			
		}else if(!carpetaDeTrabajo.exists()){//en el caso de que no exista nos saldra un error
			
			throw new GestionFicherosException("La acci�n no se ha completado, no existe la carpeta");//el error
			
		}else {
			
			cTrabajo.mkdir();//funcion para crear la carpeta
			actualiza();//uso del metodo actualizar
			
		}
				
			
		}

	@Override
	public void creaFichero(String arg0) throws GestionFicherosException {//metodo para crear ficheros con sus excepciones
		// TODO Auto-generated method stub
		
		File cTrabajo = new File(carpetaDeTrabajo, arg0);
		
		try {
			
			cTrabajo.createNewFile();//funcion para crear el fichero
			actualiza();
			
		}catch (IOException e){
			
			if (!carpetaDeTrabajo.canWrite()) {
				
				throw new GestionFicherosException("La accion no se ha completado, no tienes permisos");
				
			}else if(!carpetaDeTrabajo.exists()) {
				
				throw new GestionFicherosException("La accion no se ha completado, no existe la carpeta");
									
			}
			
		}
	}

	@Override
	public void elimina(String arg0) throws GestionFicherosException {//metodo para eliminar directorios o ficheros
		// TODO Auto-generated method stub
		
		File cTrabajo = new File (carpetaDeTrabajo, arg0);
		
		if(!carpetaDeTrabajo.canWrite()) {
			
			throw new GestionFicherosException("La accion no se ha completado, no tienes permisos");
			
		}else if(!carpetaDeTrabajo.exists()){
			
			throw new GestionFicherosException("La accion no se ha completado, no existe la carpeta");
			
		}else if(!cTrabajo.exists()){
			
			throw new GestionFicherosException("La accion no se ha completado, no existe el archivo");
			
		}else {
			
			cTrabajo.delete();//funcion para eliminar la carpeta
			actualiza();
			
		}

	}

	@Override
	public void entraA(String arg0) throws GestionFicherosException {//metodo para entrar a las carpetas/ficheros
		// TODO Auto-generated method stub
		
		File cTrabajo = new File(carpetaDeTrabajo, arg0);

		if(!cTrabajo.exists()) {

			throw new GestionFicherosException("La accion no se ha completado, no existe la carpeta");
		}

		if(!cTrabajo.isDirectory()) {

			throw new GestionFicherosException("La accion no se ha completado, no es un directorio");
		}
		
		if(!cTrabajo.canRead()) {
			
			throw new GestionFicherosException("La accion no se ha completado, no se puede leer");
			
		}
		carpetaDeTrabajo = cTrabajo;
		actualiza();
	}
	

	@Override
	public int getColumnas() {
		// TODO Auto-generated method stub
		return columnas;
	}

	@Override
	public Object[][] getContenido() {
		// TODO Auto-generated method stub
		return contenido;
	}

	@Override
	public String getDireccionCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getAbsolutePath();
	}

	@Override
	public String getEspacioDisponibleCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getEspacioTotalCarpetaTrabajo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int getFilas() {
		// TODO Auto-generated method stub
		return filas;
	}

	@Override
	public FormatoVistas getFormatoContenido() {
		// TODO Auto-generated method stub
		return formatoVistas;
	}

	@Override
	public String getInformacion(String arg0) throws GestionFicherosException {//metodo para obtener informacion
		// TODO Auto-generate	d method stub
		
		File cTrabajo = new File(carpetaDeTrabajo, arg0);//creamos la carpeta
		
		if (!cTrabajo.exists()) throw new GestionFicherosException("La accion no se ha completado, el archivo no existe");//expeciones por si no existe el documento
		
		StringBuilder sb = new StringBuilder();//creamos el string builder
		SimpleDateFormat fecha = new SimpleDateFormat("MM/dd/yyy");//variable para que nos guarde la fecha
		
		sb.append("-----------------INFORMACION_DEL_FICHERO-----------------"+"\n\n");
		
		
		sb.append("Nombre: "+cTrabajo.getName());//nombre
		sb.append("\n");
		
		if(cTrabajo.isDirectory()==true){//clase			
			sb.append("Es un directorio");//Caso de que sea directorio
			sb.append("\n");
			sb.append("Elementos que contiene: "+cTrabajo.list().length);
			sb.append("\n");
			sb.append("Espacio libre(Mb): "+(cTrabajo.getFreeSpace()/1048576));
			sb.append("\n");
			sb.append("Espacio disponible(Mb): "+(cTrabajo.getUsableSpace()/1048576));
			sb.append("\n");
			sb.append("Espacio total(Mb): "+(cTrabajo.getTotalSpace()/1048576));
			sb.append("\n");

		}else {	
			sb.append("Es un fichero");//caso de que sea fichero
			
			sb.append("Tama�o en bytes: "+cTrabajo.length());//tama�o en bytes de la carpeta
		}
		sb.append("\n");
		
		sb.append("Ubicaion: "+cTrabajo.getAbsolutePath());//ubicacion
		sb.append("\n");
		
		sb.append("Modificaciones: " + fecha.format(cTrabajo.lastModified()));//Ultima modificacion
		sb.append("\n");
		
		if(cTrabajo.isHidden()==true){//vista			
			sb.append("Vista: esta oculto");
			
		}else {	
			sb.append("Vista: no esta oculto");			
		}
		sb.append("\n");
		
		String cadena = sb.toString();
		return cadena;
		
	}

	@Override
	public boolean getMostrarOcultos() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String getNombreCarpeta() {
		// TODO Auto-generated method stub
		return carpetaDeTrabajo.getName();
	}

	@Override
	public TipoOrden getOrdenado() {
		// TODO Auto-generated method stub
		return ordenado;
	}

	@Override
	public String[] getTituloColumnas() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long getUltimaModificacion(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String nomRaiz(int arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int numRaices() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void renombra(String arg0, String arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub
		
		File cTrabajo = new File(carpetaDeTrabajo, arg0);
		
		if (!carpetaDeTrabajo.canWrite()) {
			
			throw new GestionFicherosException("La accion no se ha completado, no tienes permisos");
			
		}else if(!carpetaDeTrabajo.exists()) {
			
			throw new GestionFicherosException("La accion no se ha completado, no existe la carpeta");
								
		}else {
			
			File cTrabajoRen = new File(carpetaDeTrabajo, arg1);
			cTrabajo.renameTo(cTrabajoRen);
			actualiza();
			
		}

	}

	@Override
	public boolean sePuedeEjecutar(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sePuedeEscribir(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sePuedeLeer(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setColumnas(int arg0) {
		// TODO Auto-generated method stub
		columnas = arg0;

	}

	@Override
	public void setDirCarpeta(String arg0) throws GestionFicherosException {
		// TODO Auto-generated method stub
		File file = new File(arg0);

		if(!file.exists()) {

			throw new GestionFicherosException("ERROR. Se esperaba un directorio, pero "+file.getAbsolutePath()+ "no existe");
		}

		if(!file.isDirectory()) {

			throw new GestionFicherosException("ERROR. Se esperaba un directorio, pero "+file.getAbsolutePath()+ "no lo es");
		}
		
		if(!file.canRead()) {
			
			//throw new 
			//TODO ACABAR METODO
		}
		carpetaDeTrabajo = file;
		actualiza();
	}

	@Override
	public void setFormatoContenido(FormatoVistas arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setMostrarOcultos(boolean arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setOrdenado(TipoOrden arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSePuedeEjecutar(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSePuedeEscribir(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSePuedeLeer(String arg0, boolean arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setUltimaModificacion(String arg0, long arg1) throws GestionFicherosException {
		// TODO Auto-generated method stub

	}

}
